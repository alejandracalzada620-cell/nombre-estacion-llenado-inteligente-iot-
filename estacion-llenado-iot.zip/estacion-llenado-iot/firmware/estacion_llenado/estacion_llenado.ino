/*
 * ESTACION DE LLENADO INTELIGENTE CON PARO DE EMERGENCIA  (EL-IoT)
 * Materia: Tecnologias Emergentes y Transformacion Digital - TecNM
 * Placa  : Arduino UNO / Nano (ATmega328P, 5 V)
 *
 * Caracteristicas de diseno:
 *   - SIN delay(): todo el temporizado usa millis() (no bloqueante).
 *   - Maquina de estados: REPOSO, LLENANDO, LLENO, ALARMA, ESTOP.
 *   - Paro de emergencia por interrupcion externa (INT0, pin D2).
 *   - Lectura de eco ultrasonico por interrupcion (INT1, pin D3).
 *   - Transmision serie NO bloqueante (cola propia + availableForWrite()).
 *   - Payload JSON en una linea terminada en '\n' a 115200 baudios.
 *
 * Comandos aceptados por serie (texto + '\n'):
 *   START | STOP | RESET | AUTO,1 | AUTO,0 | PING,<n>
 */
#include <Arduino.h>

#define FW_VERSION "1.0"

// ===================== PINES =====================
const uint8_t PIN_ESTOP        = 2;   // INT0. Contacto NC a GND, INPUT_PULLUP
const uint8_t PIN_ECHO         = 3;   // INT1. HC-SR04 ECHO
const uint8_t PIN_BTN_START    = 4;   // Pulsador NA a GND
const uint8_t PIN_BTN_RESET    = 5;   // Pulsador NA a GND
const uint8_t PIN_RELE         = 7;   // Modulo rele optoacoplado (activo en BAJO)
const uint8_t PIN_TRIG         = 9;   // HC-SR04 TRIG
const uint8_t PIN_LED_VERDE    = 11;
const uint8_t PIN_LED_AMARILLO = 12;
const uint8_t PIN_LED_ROJO     = 13;
const uint8_t PIN_LM35         = A0;  // LM35, 10 mV/grado C

const uint8_t RELE_ON  = LOW;
const uint8_t RELE_OFF = HIGH;

// ===================== PARAMETROS =====================
const float    ALTURA_TANQUE_CM = 20.0;  // distancia sensor -> fondo (calibrar)
const float    DIST_MIN_CM      = 2.0;   // zona ciega del HC-SR04
const float    DIST_MAX_CM      = 400.0;
const float    NIVEL_LLENO      = 90.0;  // % para detener bomba
const float    NIVEL_BAJO       = 30.0;  // % para re-arrancar (modo AUTO)
const float    TEMP_MAX_C       = 60.0;  // sobretemperatura -> ALARMA
const float    INCREMENTO_MIN   = 1.0;   // % minimo de avance en T_SIN_FLUJO_MS
const uint8_t  FALLOS_SENSOR_MAX = 5;

const uint32_t T_SENSOR_MS      = 100;   // periodo de disparo ultrasonico
const uint32_t T_ECHO_TIMEOUT   = 30;    // espera maxima de eco
const uint32_t T_TEMP_MS        = 200;   // periodo de lectura LM35
const uint32_t T_TELEMETRIA_MS  = 500;   // periodo de envio JSON
const uint32_t T_SIN_FLUJO_MS   = 30000; // bomba encendida sin subir nivel
const uint32_t T_REBOTE_MS      = 30;    // anti-rebote de botones

// ===================== ESTADOS =====================
enum Estado : uint8_t { ST_REPOSO, ST_LLENANDO, ST_LLENO, ST_ALARMA, ST_ESTOP };
const char* const NOMBRE_ESTADO[] = { "REPOSO", "LLENANDO", "LLENO", "ALARMA", "ESTOP" };

enum Alarma : uint8_t { AL_NINGUNA, AL_SOBRETEMP, AL_SENSOR, AL_SIN_FLUJO };
const char* const NOMBRE_ALARMA[] = { "NINGUNA", "SOBRETEMP", "SENSOR", "SIN_FLUJO" };

Estado  estado  = ST_REPOSO;
Alarma  alarma  = AL_NINGUNA;

// ===================== VARIABLES GLOBALES =====================
// --- Interrupciones ---
volatile bool          g_estopFlag = false;
volatile uint32_t      g_echoInicio = 0;
volatile uint32_t      g_echoUs = 0;
volatile bool          g_echoListo = false;

// --- Mediciones ---
float    distCm = 0, nivelPct = 0, tempC = 0;
bool     distValida = false;
uint8_t  fallosSensor = 0;
bool     bombaOn = false;
bool     modoAuto = false;

// --- Temporizadores (millis) ---
uint32_t tSensor = 0, tTemp = 0, tTelem = 0, tDisparo = 0;
uint32_t tProgreso = 0;
bool     esperandoEco = false;
float    nivelProgreso = 0;

// --- Peticiones de usuario ---
bool reqStart = false, reqStop = false, reqReset = false;

// --- Comunicacion ---
uint32_t seq = 0;
char     rxBuf[24];
uint8_t  rxLen = 0;
char     txBuf[170];
uint8_t  txLen = 0, txPos = 0;
bool     telemPendiente = false;
bool     pongPendiente = false;
uint32_t pongId = 0;

// --- Botones con anti-rebote no bloqueante ---
struct Boton {
  uint8_t  pin;
  bool     lectura;   // ultima lectura cruda
  bool     estable;   // estado filtrado
  uint32_t tCambio;
  bool     flanco;    // pulsacion pendiente de atender
};
Boton btnStart = { PIN_BTN_START, HIGH, HIGH, 0, false };
Boton btnReset = { PIN_BTN_RESET, HIGH, HIGH, 0, false };

// ===================== UTILIDADES =====================
// Devuelve true cada 'periodo' ms (patron de temporizador no bloqueante)
bool vencido(uint32_t &ultimo, uint32_t periodo) {
  uint32_t ahora = millis();
  if ((uint32_t)(ahora - ultimo) >= periodo) {
    ultimo = ahora;
    return true;
  }
  return false;
}

void bomba(bool encender) {
  bombaOn = encender;
  digitalWrite(PIN_RELE, encender ? RELE_ON : RELE_OFF);
}

// ===================== ISR =====================
// Paro de emergencia: apaga el rele DENTRO de la interrupcion (latencia de microsegundos)
void isrEstop() {
  digitalWrite(PIN_RELE, RELE_OFF);
  g_estopFlag = true;
}

void isrEcho() {
  if (digitalRead(PIN_ECHO)) {
    g_echoInicio = micros();
  } else {
    g_echoUs = micros() - g_echoInicio;
    g_echoListo = true;
  }
}

// ===================== BOTONES =====================
void actualizarBoton(Boton &b) {
  bool l = digitalRead(b.pin);
  if (l != b.lectura) {
    b.lectura = l;
    b.tCambio = millis();
  }
  if ((uint32_t)(millis() - b.tCambio) >= T_REBOTE_MS && b.estable != b.lectura) {
    b.estable = b.lectura;
    if (b.estable == LOW) b.flanco = true;   // flanco de bajada = pulsacion
  }
}

bool pulsado(Boton &b) {
  if (b.flanco) { b.flanco = false; return true; }
  return false;
}

// ===================== SENSORES =====================
void tareaUltrasonico() {
  if (!esperandoEco) {
    if (vencido(tSensor, T_SENSOR_MS)) {
      g_echoListo = false;
      digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(2);
      digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);   // pulso de 10 us (no es delay())
      digitalWrite(PIN_TRIG, LOW);
      esperandoEco = true;
      tDisparo = millis();
    }
    return;
  }
  if (g_echoListo) {
    noInterrupts();
    uint32_t us = g_echoUs;
    g_echoListo = false;
    interrupts();
    esperandoEco = false;
    float d = us / 58.0;                       // us -> cm
    if (d >= DIST_MIN_CM && d <= DIST_MAX_CM) {
      distCm = distValida ? (0.7 * distCm + 0.3 * d) : d;   // filtro exponencial
      distValida = true;
      fallosSensor = 0;
      nivelPct = constrain((ALTURA_TANQUE_CM - distCm) / ALTURA_TANQUE_CM * 100.0, 0.0, 100.0);
    } else if (fallosSensor < 255) {
      fallosSensor++;
    }
  } else if ((uint32_t)(millis() - tDisparo) >= T_ECHO_TIMEOUT) {
    esperandoEco = false;
    if (fallosSensor < 255) fallosSensor++;
  }
}

void tareaTemperatura() {
  if (!vencido(tTemp, T_TEMP_MS)) return;
  uint16_t suma = 0;
  for (uint8_t i = 0; i < 8; i++) suma += analogRead(PIN_LM35);
  float mv = (suma / 8.0) * 1100.0 / 1023.0;   // referencia interna 1.1 V
  tempC = mv / 10.0;                           // LM35: 10 mV/grado C
}

// ===================== MAQUINA DE ESTADOS =====================
void cambiarEstado(Estado nuevo) {
  if (nuevo == estado) return;
  estado = nuevo;
  switch (nuevo) {
    case ST_LLENANDO:
      nivelProgreso = nivelPct;
      tProgreso = millis();
      bomba(true);
      break;
    default:
      bomba(false);      // cualquier otro estado deja la bomba apagada
      break;
  }
}

void maquinaEstados() {
  bool pedirStart = reqStart || pulsado(btnStart);
  bool pedirStop  = reqStop;
  bool pedirReset = reqReset || pulsado(btnReset);
  reqStart = reqStop = reqReset = false;

  // 1) PRIORIDAD MAXIMA: paro de emergencia (ISR + verificacion por sondeo)
  if (g_estopFlag || digitalRead(PIN_ESTOP) == HIGH) {
    g_estopFlag = false;
    bomba(false);
    cambiarEstado(ST_ESTOP);
  }

  // 2) Protecciones (solo si no estamos ya en ESTOP/ALARMA)
  if (estado != ST_ESTOP && estado != ST_ALARMA) {
    if (tempC >= TEMP_MAX_C)                    { alarma = AL_SOBRETEMP; cambiarEstado(ST_ALARMA); }
    else if (fallosSensor >= FALLOS_SENSOR_MAX) { alarma = AL_SENSOR;    cambiarEstado(ST_ALARMA); }
  }

  // 3) Logica por estado
  switch (estado) {
    case ST_REPOSO:
      if (distValida && nivelPct < NIVEL_LLENO &&
          (pedirStart || (modoAuto && nivelPct < NIVEL_BAJO))) {
        cambiarEstado(ST_LLENANDO);
      }
      break;

    case ST_LLENANDO:
      if (pedirStop) {
        cambiarEstado(ST_REPOSO);
      } else if (nivelPct >= NIVEL_LLENO) {
        cambiarEstado(ST_LLENO);
      } else if (nivelPct >= nivelProgreso + INCREMENTO_MIN) {
        nivelProgreso = nivelPct;            // hay avance: reinicia vigilancia
        tProgreso = millis();
      } else if ((uint32_t)(millis() - tProgreso) >= T_SIN_FLUJO_MS) {
        alarma = AL_SIN_FLUJO;               // bomba girando en seco o fuga
        cambiarEstado(ST_ALARMA);
      }
      break;

    case ST_LLENO:
      if (nivelPct < NIVEL_BAJO) cambiarEstado(ST_REPOSO);
      break;

    case ST_ALARMA:
      if (pedirReset && tempC < (TEMP_MAX_C - 5.0) && fallosSensor < FALLOS_SENSOR_MAX) {
        alarma = AL_NINGUNA;
        cambiarEstado(ST_REPOSO);
      }
      break;

    case ST_ESTOP:
      // Enclavado: solo sale si el hongo YA fue liberado (pin en LOW) y se pulsa RESET
      if (pedirReset && digitalRead(PIN_ESTOP) == LOW) {
        alarma = AL_NINGUNA;
        cambiarEstado(ST_REPOSO);
      }
      break;
  }
}

// ===================== INDICADORES =====================
void tareaLeds() {
  uint32_t m = millis();
  bool v = false, a = false, r = false;
  switch (estado) {
    case ST_REPOSO:   a = true;                 break;
    case ST_LLENANDO: v = true;                 break;
    case ST_LLENO:    v = (m / 500) % 2;        break;   // parpadeo 1 Hz
    case ST_ALARMA:   a = (m / 125) % 2;        break;   // parpadeo 4 Hz
    case ST_ESTOP:    r = true;                 break;
  }
  digitalWrite(PIN_LED_VERDE, v);
  digitalWrite(PIN_LED_AMARILLO, a);
  digitalWrite(PIN_LED_ROJO, r);
}

// ===================== COMUNICACION SERIE =====================
void procesarComando(const char* c) {
  if      (strcmp(c, "START") == 0)        reqStart = true;
  else if (strcmp(c, "STOP")  == 0)        reqStop  = true;
  else if (strcmp(c, "RESET") == 0)        reqReset = true;
  else if (strncmp(c, "AUTO,", 5) == 0)    modoAuto = (c[5] == '1');
  else if (strncmp(c, "PING,", 5) == 0)  { pongId = strtoul(c + 5, NULL, 10); pongPendiente = true; }
}

void tareaRx() {
  while (Serial.available() > 0) {
    char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (rxLen > 0) {
        rxBuf[rxLen] = '\0';
        procesarComando(rxBuf);
        rxLen = 0;
      }
    } else if (rxLen < sizeof(rxBuf) - 1) {
      rxBuf[rxLen++] = ch;
    } else {
      rxLen = 0;                              // desbordamiento: descartar linea
    }
  }
}

// Formatea un float con 1 decimal sin usar %f (AVR no lo soporta en snprintf)
void fmt1(char* dst, float v) {
  if (v < 0) v = 0;
  long x = lroundf(v * 10.0f);
  sprintf(dst, "%ld.%ld", x / 10, x % 10);
}

void armarTelemetria() {
  char sn[10], sd[10], st[10];
  fmt1(sn, nivelPct); fmt1(sd, distCm); fmt1(st, tempC);
  int n = snprintf(txBuf, sizeof(txBuf),
    "{\"id\":%lu,\"t\":%lu,\"st\":\"%s\",\"niv\":%s,\"dist\":%s,\"temp\":%s,"
    "\"bomba\":%d,\"estop\":%d,\"auto\":%d,\"alm\":\"%s\"}\n",
    (unsigned long)seq++, (unsigned long)millis(), NOMBRE_ESTADO[estado], sn, sd, st,
    bombaOn ? 1 : 0, digitalRead(PIN_ESTOP) == HIGH ? 1 : 0, modoAuto ? 1 : 0,
    NOMBRE_ALARMA[alarma]);
  txLen = (n > 0 && n < (int)sizeof(txBuf)) ? (uint8_t)n : 0;
  txPos = 0;
}

void armarPong() {
  int n = snprintf(txBuf, sizeof(txBuf), "{\"pong\":%lu,\"t\":%lu}\n",
                   (unsigned long)pongId, (unsigned long)millis());
  txLen = (n > 0) ? (uint8_t)n : 0;
  txPos = 0;
}

// Empuja bytes al UART solo si hay espacio => Serial.write() nunca bloquea
void tareaTx() {
  while (txPos < txLen && Serial.availableForWrite() > 0) {
    Serial.write(txBuf[txPos++]);
  }
  if (txPos >= txLen) { txPos = 0; txLen = 0; }

  if (vencido(tTelem, T_TELEMETRIA_MS)) telemPendiente = true;

  if (txLen == 0) {                       // cola libre: elegir el siguiente mensaje
    if (pongPendiente)        { armarPong();       pongPendiente = false; }
    else if (telemPendiente)  { armarTelemetria(); telemPendiente = false; }
  }
}

// ===================== SETUP / LOOP =====================
void setup() {
  digitalWrite(PIN_RELE, RELE_OFF);          // evita pulso al arrancar
  pinMode(PIN_RELE, OUTPUT);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LED_VERDE, OUTPUT);
  pinMode(PIN_LED_AMARILLO, OUTPUT);
  pinMode(PIN_LED_ROJO, OUTPUT);
  pinMode(PIN_ESTOP, INPUT_PULLUP);
  pinMode(PIN_BTN_START, INPUT_PULLUP);
  pinMode(PIN_BTN_RESET, INPUT_PULLUP);

  analogReference(INTERNAL);                 // 1.1 V -> resolucion ~0.1 C con LM35
  analogRead(PIN_LM35);                      // lectura de descarte tras cambiar referencia

  Serial.begin(115200);

  attachInterrupt(digitalPinToInterrupt(PIN_ESTOP), isrEstop, RISING);
  attachInterrupt(digitalPinToInterrupt(PIN_ECHO),  isrEcho,  CHANGE);

  if (digitalRead(PIN_ESTOP) == HIGH) {      // hongo presionado o cable roto al encender
    estado = ST_ESTOP;
  }
}

void loop() {
  actualizarBoton(btnStart);
  actualizarBoton(btnReset);
  tareaRx();
  tareaUltrasonico();
  tareaTemperatura();
  maquinaEstados();
  tareaLeds();
  tareaTx();
}
